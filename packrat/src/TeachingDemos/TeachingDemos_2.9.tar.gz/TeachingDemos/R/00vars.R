slider.env <- new.env()
