earth/inst/slowtests/README
---------------------------

The tests in this directory are much more comprehensive than
tests\test.earth.R but also take much longer to execute (a 
few minutes).

Note that the test reference postscript files are not included here
(and are not included with the earth release), because they are very
big (over 35 MBytes in total).

None of these tests do much testing of appropriate behaviour for bad
arguments.

For some OLD timing test results: see timing-tests.txt

For timing tests (as shown on the earth web page): run earth.times.bat

Stephen Milborrow Apr 2007 Petaluma
